app.controller('AddMenu', ['$scope', '$rootScope', '$cookies', function($scope, $rootScope, $cookies) {
    var validate = $cookies.get('validate');
    if(validate === 'true') {
        var loggedUser = $cookies.get('logged_user');
        if(loggedUser) {
            $rootScope.loggedUser = loggedUser;
        }
        $rootScope.validate = true;
    }else {
        $rootScope.validate = false;
    }
    $scope.loginPage = true;
    $rootScope.errorMessage = false;

    /**-------------------------------------------SET-EMPTY-LOGIN-OBJECT-DATA---------------------------------------------*/
    $scope.init = function() {
        $scope.active = false;
        $scope.editMenu = false;
    };

    $scope.editMenuAction = function() {
        $scope.editMenu = true;
        $scope.menu.backupName = $scope.menu.name;
        $scope.menu.backupDescription = $scope.menu.description;
    };


    $scope.setEmptyMenuData = function () {
        $scope.menu = {
            name: 'Menu',
            description: 'Get people excited about your menu and your food. Give your menu a brief description',
            backupName: '',
            backupDescription: '',
            sections: [
                {name: 'Appetizers', description: 'This is a section of your menu. Give your section a brief description', backupName: '', backupDescription: '', editSection: false, active: false, addPhoto: 'photo', photo: '', backgroundStyle: '', id: 0},
                {name: 'Entrees', description: 'This is a section of your menu. Give your section a brief description', backupName: '', backupDescription: '', editSection: false, active: false, addPhoto: 'photo', photo: '', backgroundStyle: '', id: 1},
                {name: 'Desserts', description: 'This is a section of your menu. Give your section a brief description', backupName: '', backupDescription: '', editSection: false, active: false, addPhoto: 'photo', photo: '', backgroundStyle: '', id: 2}
            ]
        }
    };
    $scope.setEmptyMenuData();


    $scope.closeSaving = function() {
        $scope.editMenu = false;
        $scope.menu.name = $scope.menu.backupName;
        $scope.menu.description = $scope.menu.backupDescription;
    };
    $scope.saveMenuChanges = function() {
        $scope.editMenu = false;
    };


/*----------------------------------------------------Section---------------------------------------------------------*/
    /*
    $scope.sectionsInit = function() {
        var i;
        for(i in $scope.menu.sections) {
            i.editSection = false;
        }
        console.log($scope.menu);
    };
    $scope.sectionsInit();
    */
    $scope.editSectionAction = function(x) {
        console.log(x.name);
        x.editSection = true;
        x.backupName = x.name;
        x.backupDescription = x.description;
    };
    $scope.closeSectionSaving = function(x) {
        x.editSection = false;
        x.name = x.backupName;
        x.description = x.backupDescription;
    };
    $scope.saveSectionChanges = function(x) {
        x.editSection = false;
    };
/*------------------------------------------------Section Image-------------------------------------------------------*/
$scope.showPhoto = function(x) {
    if( x.addPhoto !== 'image') {
        x.addPhoto = 'photo'
    }
    console.log(x.addPhoto);
};
$scope.showPlus = function(x) {
    if( x.addPhoto !== 'image') {
        x.addPhoto = 'plus'
    }
    console.log(x.addPhoto);
};
$scope.showImage = function(x) {
    x.addPhoto = 'image'
};
/*--------------------------------------------------Adding Image------------------------------------------------------*/
    $scope.myImage = '';

    var handleFileSelect = function (evt) {
        //console.log(this);
        console.log(evt);
        console.log(evt.data.id);
        var currentSectionId = evt.data.id;
        var file = evt.currentTarget.files[0];
        console.log(file);
        var reader = new FileReader();
        //console.log(reader);

        reader.onload = function (evt) {
            $scope.$apply(function ($scope) {
                //console.log(evt.target.result); // our file
                $scope.myImage = evt.target.result;
                if(evt.target.result) {
                    $scope.menu.sections[currentSectionId].photo = evt.target.result;
                    //$scope.menu.sections[currentSectionId].backgroundStyle = ' background-image: url("' + evt.target.result + '");';
                    $scope.showImage($scope.menu.sections[currentSectionId]);
                }
            });
        };
        reader.readAsDataURL(file);


    };
    //console.log(document.querySelector('.sectionImg'));
    //console.log(angular.element(document.querySelector('.sectionImg')));

    $scope.$on('ngRepeatFinished', function(ngRepeatFinishedEvent) {
        //console.log(ngRepeatFinishedEvent);
        //angular.element('.sectionImg').on('change', handleFileSelect);
    });

    $scope.someFunc = function(x) {
        //angular.element('.sectionImg').on('change', handleFileSelect);
        console.log(x.addPhoto);
        console.log(x.id);
        //console.log(this);
        console.log(angular.element('.sectionImg')[x.id]);
        angular.element(angular.element('.sectionImg')[x.id]).on('change', {id: x.id}, handleFileSelect);
        //console.log($event);
        //this.onclick = handleFileSelect;
    }
}]);


