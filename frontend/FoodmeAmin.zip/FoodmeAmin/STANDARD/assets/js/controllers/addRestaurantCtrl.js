app.controller('AddRestaurant', ['$scope', '$rootScope', '$cookies', '$http', 'NgMap', 'httpGetQuery', 'httpPostQuery', 'httpPutQuery', function($scope, $rootScope, $cookies, $http, NgMap, httpGetQuery, httpPostQuery, httpPutQuery) {
    var validate = $cookies.get('validate'),
        loggedUser = $cookies.get('logged_user'),
        restaurantId = $cookies.get('restaurant_Id'),
        facebookToken = $cookies.get('access_token');
    if(validate === 'true') {
        if(loggedUser) {
            $rootScope.loggedUser = loggedUser;
        }
        if(restaurantId) {
            console.log('works');
            $scope.restaurantDataPromiseGet = httpGetQuery.getData('http://harristest.com.mocha6001.mochahost.com/foodme/restaurant/' + restaurantId);
            $scope.restaurantDataPromiseGet.then(function(value) {
                console.log('object is retrieved, reply is:');
                if(value) {
                    console.log(value);
                    $scope.fillingRestaurantData(value);
                    $scope.position = [value.geoLocation.latitude, value.geoLocation.longitude];
                    console.log($scope.position);
                }
            });
        }

        if(facebookToken) {
            console.log('facebook works');
            $scope.facebookTokenPromiseGet = httpGetQuery.getData('http://harristest.com.mocha6001.mochahost.com/foodme/facebook/' + facebookToken);
            $scope.facebookTokenPromiseGet.then(function(value) {
                console.log('facebook object is retrieved, reply is:');
                if(value) {
                    console.log(value);
                    $scope.fillingRestaurantData(value);
                    $scope.position = [value.geoLocation.latitude, value.geoLocation.longitude];
                    console.log($scope.position);
                }
            });
        }

        $rootScope.validate = true;

    }else {
        $rootScope.validate = false;
    }
    $scope.loginPage = true;
    $rootScope.errorMessage = false;

    /**-------------------------------------------SET-EMPTY-LOGIN-OBJECT-DATA---------------------------------------------*/
    $scope.addressOptions = [
        {name: 'Show after address', shortName: 'after'},
        {name: 'Show instead of address', shortName: 'instead'}
    ];
    $scope.languageOptions = [
        {name: 'English (United States)', shortName: 'EN'}
    ];
    $scope.currencyOptions = [
        {name: 'United States dollar $', shortName: 'USD'}
    ];
    $scope.setEmptyRegisterRestaurantData = function () {
        $scope.restaurantData = {
            name: '',
            description: '',
            address: '',
            addressDescription: '',
            selectedAddressOption: 'after',
            geoLocation: {
                latitude: '',
                longitude: ''
            },
            email: '',
            phoneNumber: '',
            faxNumber: '',
            openingHours: {
                Mn: {from: '8:00', till: '21:00'},
                Tu: {from: '8:00', till: '21:00'},
                Wd: {from: '8:00', till: '21:00'},
                Th: {from: '8:00', till: '21:00'},
                Fr: {from: '8:00', till: '21:00'},
                Sa: {from: '8:00', till: '21:00'},
                Su: {from: '8:00', till: '21:00'}
            },
            language: 'EN',
            currency: 'USD'
        }
    };
    $scope.setEmptyRegisterRestaurantData();
    $scope.fillingRestaurantData = function (value) {
        $scope.restaurantData = {
            name: value.name,
            description: value.description,
            address: value.address,
            //addressDescription: value.addressDescription,
            //selectedAddressOption: value.selectedAddressOption,
            geoLocation: {
                latitude: value.geoLocation.latitude,
                longitude: value.geoLocation.longitude
            },
            email: value.email,
            phoneNumber: value.phoneNumber,
            faxNumber: value.faxNumber
            /*openingHours: {
                Mn: {from: value.openingHours.Mn.from, till: value.openingHours.Mn.till},
                Tu: {from: value.openingHours.Tu.from, till: value.openingHours.Tu.till},
                Wd: {from: value.openingHours.Wd.from, till: value.openingHours.Wd.till},
                Th: {from: value.openingHours.Th.from, till: value.openingHours.Th.till},
                Fr: {from: value.openingHours.Fr.from, till: value.openingHours.Fr.till},
                Sa: {from: value.openingHours.Sa.from, till: value.openingHours.Sa.till},
                Su: {from: value.openingHours.Su.from, till: value.openingHours.Su.till}
            },
            language: value.language,
            currency: value.currency*/
        }
    };

    $scope.lengthControl = function() {
        if($scope.restaurantData.description.length >= 150) {
            $scope.restaurantData.description = $scope.restaurantData.description.substr(0, 150);
        }
    };

    $scope.showPosition = function() {
        console.log($scope.restaurantData.address);
        if ($scope.restaurantData.address === '' || $scope.restaurantData.address === undefined) {
                navigator.geolocation.getCurrentPosition(function(pos) {
                    console.log(pos);
                    $scope.position = [pos.coords.latitude, pos.coords.longitude];
                    //$scope.position = new google.maps.LatLng(pos.coords.latitude, pos.coords.longitude);
                },
                function(error) {
                    alert('Unable to get location: ' + error.message);
                }, {enableHighAccuracy: true});
        } else if($scope.restaurantData.address && $scope.restaurantData.address !== '') {
            $scope.position = $scope.restaurantData.address.trim();
        }
    };
    if(!restaurantId) {
        $scope.showPosition();
    }


    $scope.markerClick = function() {
        console.log(this); //marker
        console.log(this.map.getCenter().lat()); //map center position
        console.log(this.getPosition().lat()); //marker position
    };

    $scope.centreChange = function() {
        //console.log(this); //map
        //console.log(this.getCenter().lat()); //map center position
        //console.log(this.markers[0].getPosition().lat()); //marker position
        var mapPosition = this.getCenter(),
            mapPositionLat = mapPosition.lat(),
            mapPositionLng = mapPosition.lng(),
            markerPosition = this.markers[0].getPosition(),
            markerPositionLat = markerPosition.lat(),
            markerPositionLng = markerPosition.lng();
/*
        if(markerPositionLat !== 0 && markerPositionLng !== 0) {
            $scope.restaurantData.geoLocation = {
                latitude: markerPositionLat,
                longitude: markerPositionLng
            };

        } else {

        }
        */
        $scope.restaurantData.geoLocation = {
            latitude: mapPositionLat,
            longitude: mapPositionLng
        };
        console.log(mapPositionLat + ' x ' + mapPositionLng);
        console.log(markerPositionLat + ' x ' + markerPositionLng); //marker one step late of map position, we can't use it
        //console.log($scope.restaurantData.geoLocation);
    };

/**------------------------------------------------ALL-OBJ-SAVING-----------------------------------------------------*/
$scope.addNewRestaurantObject = function (form) {
    console.log(form);
    var firstError = null;
    if (form.$invalid) {
        var field = null, firstError = null;
        for (field in form) {
            if (field[0] != '$') {
                if (firstError === null && !form[field].$valid) {
                    firstError = form[field].$name;
                }
                if (form[field].$pristine) {
                    form[field].$dirty = true;
                }
            }
        }
        angular.element('.ng-invalid[name=' + firstError + ']').focus();
        return;
    } else {

        console.log('hello');
        console.log($scope.restaurantData);
        var restaurantId = $cookies.get('restaurant_Id'),
            accountId = $cookies.get("account_Id");
        if(accountId) {
            if(!restaurantId) {
                $scope.restaurantDataPromisePost = httpPostQuery.postData('http://harristest.com.mocha6001.mochahost.com/foodme/account/' + accountId + '/restaurant', $scope.restaurantData);
                $scope.restaurantDataPromisePost.then(function(value) {
                    console.log('object is send, reply is:');
                });
            } else {
                $scope.restaurantDataPromisePut = httpPutQuery.putData('http://harristest.com.mocha6001.mochahost.com/foodme/restaurant/' + restaurantId, $scope.restaurantData);
                $scope.restaurantDataPromisePut.then(function(value) {
                    console.log('object is updated, reply is:');
                });
            }
        }
    }
};
/**---------------------------------------------------CANCEL----------------------------------------------------------*/
$scope.cancelFunctionality = function() {
    var restaurantId = $cookies.get('restaurant_Id'),
        accountId = $cookies.get("account_Id");
    if(accountId) {
        if(!restaurantId) {
            $scope.setEmptyRegisterRestaurantData();
        } else {
            $scope.restaurantDataPromiseGet = httpGetQuery.getData('http://harristest.com.mocha6001.mochahost.com/foodme/restaurant/' + restaurantId);
            $scope.restaurantDataPromiseGet.then(function(value) {
                console.log('object is retrieved, reply is:');
                if(value) {
                    console.log(value);
                    $scope.fillingRestaurantData(value);
                }
            });
        }
    }
}



}]);
