app.factory('AuthService', ['$http', '$cookies', '$rootScope', '$httpParamSerializer', '$timeout', function ($http, $cookies, $rootScope, $httpParamSerializer, $timeout) {
    var authObj = {
        authEncoded: btoa("foodmeWeb:bfe0ff72-66c7-48e8-9719-3a0cf9851015"), //btoa - window method with encode a string in base-64
        //Zm9vZG1lV2ViOmJmZTBmZjcyLTY2YzctNDhlOC05NzE5LTNhMGNmOTg1MTAxNQ==
        login: function(paramData) {
            //console.log(paramData);
            var req = {
                method: 'POST',
                url: "http://harristest.com.mocha6001.mochahost.com/foodme/oauth/token",
                headers: {
                    "Authorization": "Basic " + this.authEncoded,
                    "Content-Type": "application/x-www-form-urlencoded; charset=utf-8"
                },
                data: $httpParamSerializer(paramData)
            };
            //console.log(req);
            return $http(req).then(function(res){
                console.log(res);
                //console.log(res.headers());
                $cookies.put("account_Id", res.data.accountId);
                $cookies.put("access_token", res.data.access_token);
                //$cookies.put("expires_in", res.data.expires_in);
                //$cookies.put("refresh_token", res.data.refresh_token);
                $cookies.put("validate", 'true');

                $rootScope.validate = true;
                $http.defaults.headers.common.Authorization = 'Bearer ' + res.data.access_token;


                authObj.getCurrentUserName().then(function(res){
                    console.log(res);
                    $rootScope.loggedUser = res.data.firstName + ' ' + res.data.lastName;
                    $cookies.put("logged_user", $rootScope.loggedUser);
                });

                var newLoginData = {
                    grant_type: "refresh_token",
                    refresh_token: res.data.refresh_token.trim()
                };
                console.log(newLoginData);
                $timeout(function(){authObj.login(newLoginData)}, res.data.expires_in * 100);

            }, function (err) {
                //console.log(err);
                $rootScope.errorMessage = true;
                $rootScope.validate = false;
                $cookies.put("validate", 'false');
            });
        },
        registration: function(paramData) {
            //console.log(paramData);
            console.log($httpParamSerializer(paramData));
            var req = {
                method: 'POST',
                url: "http://harristest.com.mocha6001.mochahost.com/foodme/account",
                headers: {
                    "Content-Type": "application/json; charset=utf-8" //application/x-www-form-urlencoded
                },
                data: JSON.stringify(paramData)
            };
            console.log(req);
            return $http(req).then(function(res){
                console.log(res);
                if(res.statusText === 'Created') {
                    $cookies.put("registered", 'true');
                }
            }, function (err) {
                console.log(err);
                $rootScope.validate = false;
                $cookies.put("validate", 'false');
            });
        },
        getCurrentUserName: function() {
            var req = {
                method: 'GET',
                url: "http://harristest.com.mocha6001.mochahost.com/foodme/account/current",
                headers: {
                    "Content-Type": "application/x-www-form-urlencoded; charset=utf-8"
                }
            };
            return $http(req);
        }
    };
return authObj;
}]);